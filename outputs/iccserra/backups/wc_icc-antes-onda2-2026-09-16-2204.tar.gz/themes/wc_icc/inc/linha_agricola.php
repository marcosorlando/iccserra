<article class="text_color_white bg_dark">
	<div class="content">
		<header class="site_header">
			<h3><b>Crédito</b> Agrícola</h3>
			<p class="text_color_white">Linha de crédito destinada a aquisição e conserto de máquinas agrícolas</p>
		</header>

		<div class="box box3">
			<p>
				<i class="icon-coin-dollar"></i><br/>
				Limite: <br/>
				mínimo R$ 600,00 <br/>
				máximo R$ 3 mil.
			</p>
		</div>
		<div class="box box3">
			<p>
				<i class="icon-calendar"></i><br/>
				Prazos: <br/>no mínimo 3 meses e<br/> no máximo 24 meses.
			</p>
		</div>
		<div class="box box3">
			<p>
				<i class="icon-calculator"></i><br/>
				Taxa de juros: <br/>
				ao mês - máxima 3,99% <br/>
				ao ano - máxima 56,45%.
		</div>

		<div class="box box3">
			<p>
				<i class="icon-user-tie"></i><br/>
				Poderá ser solicitado <br>
				avalista com renda <br>
				compatível.
			</p>
		</div>
		<div class="box box3">
			<p>
				<i class="icon-price-tags"></i><br/>
				Sujeito à aplicação <br>
				de Taxa de Abertura de <br>
				Crédito (TAC) de 3%.
			</p>
		</div>
		<div class="box box3">
			<p>
				<i class="icon-pie-chart"></i><br/>
				Você poderá comprometer<br>
				somente 20% da renda<br>
				líquida comprovada.
			</p>
		</div>

		<p class="exemplo">Exemplo de simulação de empréstimo no valor: R$ 1.000,00 | Parcelas: 12 vezes de R$ 108,48.
			Pagando as prestações em dia o valor total será de R$1.301,75. CET: 4,31% a.m e 65,92% a.a </p>

		<a href="<?= BASE; ?>/artigo/credito-agricola" class="btn_wine">Saiba Mais</a>
	</div>
</article>
