// Mede o bbox real de cada logo de marca rasterizando o SVG e procurando
// os pixels opacos. Evita ter que interpretar as curvas do path na mao.
const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

const SRC = path.join(__dirname, 'brand');
const NAMES = { facebook: 'facebook', linkedin: 'linkedin', x: 'x-twitter', whatsapp: 'whatsapp' };
const R = 512; // resolucao de medida

(async () => {
  const out = {};
  for (const [file, name] of Object.entries(NAMES)) {
    const f = path.join(SRC, `${file}.svg`);
    const svg = fs.readFileSync(f, 'utf8');
    const vb = svg.match(/viewBox="([^"]+)"/)[1].trim().split(/[\s,]+/).map(Number);
    const [vx, vy, vw, vh] = vb;

    const { data, info } = await sharp(Buffer.from(svg), { density: 600 })
      .resize(R, R, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
      .ensureAlpha().raw().toBuffer({ resolveWithObject: true });

    let x0 = info.width, y0 = info.height, x1 = -1, y1 = -1;
    for (let y = 0; y < info.height; y++) {
      for (let x = 0; x < info.width; x++) {
        if (data[(y * info.width + x) * info.channels + 3] > 8) {
          if (x < x0) x0 = x; if (x > x1) x1 = x;
          if (y < y0) y0 = y; if (y > y1) y1 = y;
        }
      }
    }
    // volta do espaco de pixels para o do viewBox
    const scale = Math.min(R / vw, R / vh);
    const padX = (R - vw * scale) / 2, padY = (R - vh * scale) / 2;
    const toVB = (px, pad, v0) => (px - pad) / scale + v0;
    const bx0 = toVB(x0, padX, vx), bx1 = toVB(x1 + 1, padX, vx);
    const by0 = toVB(y0, padY, vy), by1 = toVB(y1 + 1, padY, vy);

    out[name] = { file: f, x: bx0, y: by0, w: bx1 - bx0, h: by1 - by0 };
    console.log(`${name.padEnd(11)} viewBox=${vw}x${vh}  bbox=${bx0.toFixed(2)},${by0.toFixed(2)} ${(bx1-bx0).toFixed(2)}x${(by1-by0).toFixed(2)}`);
  }
  fs.writeFileSync(path.join(__dirname, 'bbox.json'), JSON.stringify(out, null, 1));
})();
