<?php

/**
 * WC SLIDE · widget original do WorkControl (troca por fade), restaurado a partir da produção.
 *
 * Variáveis opcionais antes do require:
 *   $SlideSeconts  int  segundos entre slides (padrão 5)
 *
 * Acessibilidade: pausa no hover/foco, botão Pausar/Reproduzir (WCAG 2.2.2),
 * paginação por botões e sem autoplay com prefers-reduced-motion.
 */

use App\Conn\Read;

$Read ??= new Read();

$Read->fullRead(
    'SELECT slide_image_mobile, slide_image_tablet, slide_image_desktop, slide_title, slide_headline, slide_desc, '
    . 'slide_link, show_headline, show_desc FROM ' . DB_SLIDES
    . ' WHERE slide_status = :status AND slide_start <= NOW() AND (slide_end >= NOW() OR slide_end IS NULL)'
    . ' ORDER BY slide_date DESC',
    'status=1'
);

if ($Read->getResult()) {
    $Slides = $Read->getResult();
    $SlideSeconds = (int)($SlideSeconts ?? 5);
    $SlideTotal = count($Slides);
    $SlideAsset = static fn (string $file): string => BASE . '/_cdn/widgets/slide/' . $file
        . '?v=' . (string)@filemtime(__DIR__ . '/' . $file);
    ?>
    <link rel="stylesheet" href="<?= $SlideAsset('slide.wc.min.css'); ?>"/>
    <script defer src="<?= $SlideAsset('slide.wc.min.js'); ?>"></script>

    <section class="wc_slides" aria-roledescription="carrossel" aria-label="Destaques"
             data-seconds="<?= $SlideSeconds; ?>">
        <?php
        foreach ($Slides as $Index => $SLIDE) {
            $ImageDesktop = $SLIDE['slide_image_desktop'];
            $ImageTablet = empty($SLIDE['slide_image_tablet']) ? $ImageDesktop : $SLIDE['slide_image_tablet'];
            $ImageMobile = empty($SLIDE['slide_image_mobile']) ? $ImageTablet : $SLIDE['slide_image_mobile'];
            $Title = htmlspecialchars((string)$SLIDE['slide_title'], ENT_QUOTES);
            $Link = htmlspecialchars((string)$SLIDE['slide_link'], ENT_QUOTES);
            $IsFirst = 0 === $Index;
            ?>
            <article class="wc_slide_item<?= $IsFirst ? ' first' : ''; ?>" aria-roledescription="slide"
                     aria-label="<?= ($Index + 1) . ' de ' . $SlideTotal; ?>"<?= $IsFirst ? '' : ' hidden'; ?>>
                <a href="<?= $Link; ?>" title="<?= $Title; ?>">
                    <picture>
                        <source media="(min-width: 992px)" srcset="<?= BASE; ?>/uploads/<?= $ImageDesktop; ?>"/>
                        <source media="(min-width: 544px)" srcset="<?= BASE; ?>/uploads/<?= $ImageTablet; ?>"/>
                        <img src="<?= BASE; ?>/uploads/<?= $ImageMobile; ?>" alt="<?= $Title; ?>"
                             width="<?= SLIDE_W; ?>" height="<?= SLIDE_H; ?>"
                             <?= $IsFirst ? 'fetchpriority="high"' : 'loading="lazy"'; ?> decoding="async"/>
                    </picture>
                </a>
                <?php if (!empty($SLIDE['show_headline']) || !empty($SLIDE['show_desc'])) { ?>
                    <div class="wc_slide_item_desc">
                        <?php
                        if (!empty($SLIDE['show_headline'])) {
                            echo "<p class='wc_slide_item_headline'><a href='{$Link}'>"
                                . htmlspecialchars((string)$SLIDE['slide_headline'], ENT_QUOTES) . '</a></p>';
                        }
                        if (!empty($SLIDE['show_desc'])) {
                            echo "<p class='wc_slide_item_text'>"
                                . htmlspecialchars((string)$SLIDE['slide_desc'], ENT_QUOTES) . '</p>';
                        }
                        ?>
                    </div>
                <?php } ?>
            </article>
            <?php
        }

        if ($SlideTotal > 1) {
            ?>
            <div class="wc_slide_controls">
                <button type="button" class="wc_slide_toggle" aria-pressed="false" aria-label="Pausar destaques">
                    <span class="wc_slide_toggle_icon" aria-hidden="true"></span>
                </button>
                <div class="wc_slide_pager">
                    <?php for ($i = 0; $i < $SlideTotal; $i++) { ?>
                        <button type="button"<?= 0 === $i ? " class='active' aria-current='true'" : ''; ?>
                                aria-label="Ir para o destaque <?= $i + 1; ?> de <?= $SlideTotal; ?>"></button>
                    <?php } ?>
                </div>
            </div>
            <?php
        }
        ?>
    </section>
    <?php
}
