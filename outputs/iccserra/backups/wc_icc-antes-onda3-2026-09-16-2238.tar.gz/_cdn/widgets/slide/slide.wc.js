/*
 * WC SLIDE · troca por fade (widget original do WorkControl, restaurado).
 * Requer jQuery. Pausa no hover/foco, botão pausar, paginação por botão e
 * sem autoplay quando o usuário prefere movimento reduzido.
 */
$(function () {
    $('.wc_slides').each(function () {
        var Slider = $(this);
        var Items = Slider.find('.wc_slide_item');
        var Dots = Slider.find('.wc_slide_pager button');
        var Toggle = Slider.find('.wc_slide_toggle');
        var Seconds = parseInt(Slider.data('seconds'), 10) || 5;
        var ReducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        var Timer = null;
        var Current = 0;
        var PausedByUser = ReducedMotion;
        var Hover = false;

        if (Items.length < 2) {
            return;
        }

        function show(index) {
            if (index === Current) {
                return;
            }

            var From = Items.eq(Current);
            var To = Items.eq(index);

            Current = index;
            Dots.removeClass('active').removeAttr('aria-current');
            Dots.eq(index).addClass('active').attr('aria-current', 'true');

            From.stop(true, true).fadeOut(400, function () {
                From.removeClass('first').attr('hidden', true);
                To.removeAttr('hidden').hide().addClass('first').fadeIn(400);
            });
        }

        function next() {
            show((Current + 1) % Items.length);
        }

        function stop() {
            clearInterval(Timer);
            Timer = null;
        }

        function start() {
            stop();
            if (!PausedByUser && !Hover) {
                Timer = setInterval(next, Seconds * 1000);
            }
        }

        function syncToggle() {
            Toggle.attr({
                'aria-pressed': PausedByUser ? 'true' : 'false',
                'aria-label': PausedByUser ? 'Reproduzir destaques' : 'Pausar destaques'
            });
            Slider.toggleClass('is-paused', PausedByUser);
        }

        Dots.on('click', function () {
            show(Dots.index(this));
            start();
        });

        Toggle.on('click', function () {
            PausedByUser = !PausedByUser;
            syncToggle();
            start();
        });

        Slider.on('mouseenter focusin', function () {
            Hover = true;
            stop();
        }).on('mouseleave focusout', function (e) {
            if (e.type === 'focusout' && Slider[0].contains(e.relatedTarget)) {
                return;
            }
            Hover = false;
            start();
        });

        syncToggle();
        start();
    });
});
